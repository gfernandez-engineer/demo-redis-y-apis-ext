package com.practica.sistema_resttemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaResttemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaResttemplateApplication.class, args);
	}

}
