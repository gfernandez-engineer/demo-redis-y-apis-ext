package com.practica.sistema_resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaResttemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
