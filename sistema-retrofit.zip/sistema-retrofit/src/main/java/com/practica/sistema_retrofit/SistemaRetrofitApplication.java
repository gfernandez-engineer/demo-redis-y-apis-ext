package com.practica.sistema_retrofit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaRetrofitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaRetrofitApplication.class, args);
	}

}
