package com.practica.sistema_openfeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaOpenfeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
