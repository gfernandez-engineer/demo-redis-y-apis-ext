package com.practica.sistema_openfeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaOpenfeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaOpenfeignApplication.class, args);
	}

}
